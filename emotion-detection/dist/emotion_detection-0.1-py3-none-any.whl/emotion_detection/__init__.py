"""emotion_detection
"""

__version__ = "0.1"
