from datetime import datetime
from typing import Any

import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import mlflow
import numpy as np
import pandas as pd
import tensorflow as tf
from keras.initializers import glorot_uniform
from keras.layers import Input, Add, Dense, Activation, BatchNormalization, Layer, Conv1D, MaxPooling1D, GlobalMaxPooling1D
from keras.metrics import AUC, Accuracy, Precision, Recall
from keras.models import Model
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay


def encoded_to_label(encoded_array: np.ndarray, label_dict: dict) -> list:
    return [list(label_dict.keys())[i] for i in encoded_array]


def create_dense_model(input_shape: int, n_classes: int, layers: list[int]) -> Model:
    input_main = Input(shape=input_shape)
    layer = input_main
    for n_neurons in layers:
        layer = Dense(n_neurons, activation="relu", kernel_regularizer="l2")(layer)

    predictions = Dense(n_classes, activation="softmax")(layer)
    model = Model(inputs=[input_main], outputs=predictions)

    return model


def identity_block(X: Layer, f: Any, filters: tuple) -> Layer:
    F1, F2 = filters
    X_shortcut = X
    X = Conv1D(filters=F1, kernel_size=f, strides=1, padding='same', kernel_initializer=glorot_uniform(seed=0))(X)
    X = BatchNormalization(axis=-1)(X)
    X = Activation('relu')(X)
    X = Conv1D(filters=F2, kernel_size=f, strides=1, padding='same', kernel_initializer=glorot_uniform(seed=0))(X)
    X = BatchNormalization(axis=-1)(X)
    X = Add()([X, X_shortcut])
    X = Activation('relu')(X)
    return X


def convolutional_block(X: Layer, f: Any, filters: tuple, s: int = 2) -> Layer:
    F1, F2 = filters
    X_shortcut = X
    X = Conv1D(F1, f, strides=s, padding='same', kernel_initializer=glorot_uniform(seed=0))(X)
    X = BatchNormalization(axis=-1)(X)
    X = Activation('relu')(X)
    X = Conv1D(F2, f, strides=1, padding='same', kernel_initializer=glorot_uniform(seed=0))(X)
    X = BatchNormalization(axis=-1)(X)
    X_shortcut = Conv1D(F2, 1, strides=s, padding='valid', kernel_initializer=glorot_uniform(seed=0))(X_shortcut)
    X_shortcut = BatchNormalization(axis=-1)(X_shortcut)
    X = Add()([X, X_shortcut])
    X = Activation('relu')(X)
    return X


def create_resnet_model(input_shape: int, n_classes: int, layers: list) -> Model:
    X_input = Input((input_shape, 1))
    X = Conv1D(64, 7, strides=2, kernel_initializer=glorot_uniform(seed=0))(X_input)
    X = BatchNormalization(axis=-1)(X)
    X = Activation('relu')(X)
    X = MaxPooling1D(3, strides=2)(X)
    for layer in layers:
        X = convolutional_block(X, f=3, filters=layer, s=1)
        X = identity_block(X, 3, layer)
    X = GlobalMaxPooling1D()(X)
    X = Dense(n_classes, activation='softmax', kernel_initializer=glorot_uniform(seed=0))(X)
    model = Model(inputs=X_input, outputs=X)
    return model


def compile_model(model: Model) -> Model:
    model.compile(
        optimizer="rmsprop",
        loss="categorical_crossentropy",
        metrics=[Accuracy(), AUC(), Precision(), Recall()],
    )
    print(model.summary())
    return model


def create_model(model_params: dict) -> Model:
    model_type = model_params["model_type"]
    input_shape = model_params["input_shape"]
    n_classes = model_params["n_classes"]
    dense_layers = model_params["dense_layers"]
    resnet_layers = model_params["resnet_layers"]

    accepted_models = ["dense", "resnet"]
    if model_type not in accepted_models:
        raise ValueError(f"The only accepted models are {accepted_models}")

    if model_type == "dense":
        if dense_layers is None:
            raise ValueError("Dense Layers not given...")
        model = create_dense_model(input_shape, n_classes, dense_layers)
    elif model_type == "resnet":
        if resnet_layers is None:
            raise ValueError("ResNet Layers not given...")
        model = create_resnet_model(input_shape, n_classes, resnet_layers)

    return compile_model(model)


def train_model(
    X_train: pd.DataFrame,
    X_val: pd.DataFrame,
    y_train: pd.DataFrame,
    y_val: pd.DataFrame,
    model_params: dict,
    train_params: dict,
) -> Model:
    model = create_model(model_params)
    batch_size = train_params["batch_size"]
    epochs = train_params["epochs"]

    print(tf.config.list_physical_devices('GPU'))

    model.fit(
        X_train,
        y_train,
        batch_size=batch_size,
        epochs=epochs,
        validation_data=(X_val, y_val),
    )

    model.save("model.keras")
    return "dummy"


def plot_confusion_matrix(confusion_matrix: np.ndarray, labels: list[str]) -> Figure:
    fig, ax = plt.subplots()
    cm = ax.matshow(confusion_matrix, cmap=plt.cm.gray_r)
    ax.set_title('Confusion Matrix')
    cax = fig.add_axes([0.92, 0.15, 0.02, 0.7])
    fig.colorbar(cm, cax=cax)
    tick_marks = np.arange(confusion_matrix.shape[1])
    ax.set_xticks(tick_marks, labels)
    ax.set_yticks(tick_marks, labels)
    ax.set_ylabel("Actual")
    ax.set_xlabel("Predicted")
    return fig


def evaluate_model(X: pd.DataFrame, y: pd.DataFrame, params: dict, dummy) -> None:
    trained_model = tf.keras.models.load_model("model.keras")
    label_dict = {
        "neutral": 0,
        "angry": 1,
        "happy": 2,
        "sad": 3,
        "disgust": 4,
        "fear": 5,
    }

    now = datetime.now()
    experiment = mlflow.set_experiment(
        experiment_name=f"experiment_{now.strftime('%d_%m_%y')}"
    )
    mlflow.autolog()
    with mlflow.start_run(
        run_name=f"{params['model_type']}_{now.strftime('%d_%m_%y_%H_%M_%S')}",
        experiment_id=experiment.experiment_id,
    ):
        y_pred = np.argmax(trained_model.predict(X, verbose=False), axis=1)
        y_pred = encoded_to_label(y_pred, label_dict)
        y_label = np.argmax(y.to_numpy(), axis=1)
        y_label = encoded_to_label(y_label, label_dict)
        labels = list(label_dict.keys())
        cm = confusion_matrix(y_label, y_pred, labels=labels)
        metrics = ["loss", "accuracy", "auc", "precision", "recall", "f1-score"]
        evaluation = trained_model.evaluate(X, y, verbose=False)
        precision, recall = evaluation[3], evaluation[4]
        evaluation += [2 * precision * recall / (precision + recall)]
        cm_disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
        cm_disp.plot()
        mlflow.log_figure(cm_disp.figure_, "confusion_matrix.png")
        mlflow.log_metrics(dict(zip(metrics, evaluation)))
        mlflow.log_params(params)
        mlflow.tensorflow.log_model(trained_model, "model.keras")
